#!/usr/bin/env python3
"""
Automated Web Security Scanner (educational project)
Checks common HTTP security headers and basic CORS behavior.
Use ONLY on websites you own or have explicit permission to test.
This is a lightweight checker, not a replacement for a professional audit.
"""
import argparse
import json
import sys
from datetime import datetime
from urllib.parse import urlparse

import requests

SECURITY_HEADERS = {
    "Strict-Transport-Security": "Helps enforce HTTPS connections.",
    "Content-Security-Policy": "Restricts the sources from which page content can load.",
    "X-Content-Type-Options": "Helps prevent MIME-type sniffing.",
    "X-Frame-Options": "Helps reduce clickjacking risk in older browser support.",
    "Referrer-Policy": "Controls how much referrer information browsers send.",
    "Permissions-Policy": "Controls access to browser features such as camera and microphone.",
}

def validate_url(url: str) -> str:
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise ValueError("Enter a complete URL beginning with http:// or https://")
    return url

def scan(url: str, timeout: float = 8.0) -> dict:
    result = {
        "target": url,
        "scan_time_utc": datetime.utcnow().isoformat(timespec="seconds") + "Z",
        "status": None,
        "final_url": None,
        "https": urlparse(url).scheme == "https",
        "headers": {},
        "missing_security_headers": [],
        "cors": {},
        "notes": [
            "Checks are indicative only; header presence does not prove a site is secure.",
            "CORS behavior depends on the requested origin and application context."
        ],
    }
    response = requests.get(
        url,
        timeout=timeout,
        allow_redirects=True,
        headers={"User-Agent": "StudentWebSecurityScanner/1.0"}
    )
    result["status"] = response.status_code
    result["final_url"] = response.url
    result["https"] = urlparse(response.url).scheme == "https"
    result["headers"] = dict(response.headers)

    for header, explanation in SECURITY_HEADERS.items():
        value = response.headers.get(header)
        if value:
            result.setdefault("security_headers_found", {})[header] = {
                "value": value,
                "purpose": explanation
            }
        else:
            result["missing_security_headers"].append({
                "header": header,
                "purpose": explanation
            })

    # A harmless, non-credentialed OPTIONS preflight-style probe.
    # It does not attempt to access private data or bypass authentication.
    try:
        options = requests.options(
            response.url,
            timeout=timeout,
            headers={
                "Origin": "https://scanner.example",
                "Access-Control-Request-Method": "GET"
            },
            allow_redirects=True
        )
        result["cors"] = {
            "allow_origin": options.headers.get("Access-Control-Allow-Origin"),
            "allow_methods": options.headers.get("Access-Control-Allow-Methods"),
            "allow_credentials": options.headers.get("Access-Control-Allow-Credentials"),
            "options_status": options.status_code,
            "interpretation": (
                "Review whether the allowed origin is appropriate for the application. "
                "A wildcard origin or reflected arbitrary origins may be risky in some contexts; "
                "this probe alone does not establish a vulnerability."
            )
        }
    except requests.RequestException as exc:
        result["cors"] = {"error": str(exc)}

    return result

def print_report(data: dict) -> None:
    print("\n=== AUTOMATED WEB SECURITY SCAN ===")
    print(f"Target: {data['target']}")
    print(f"Final URL: {data.get('final_url')}")
    print(f"HTTP status: {data.get('status')}")
    print(f"HTTPS: {'Yes' if data.get('https') else 'No'}")
    print("\nSecurity headers:")
    found = data.get("security_headers_found", {})
    for header, details in found.items():
        print(f"  [FOUND] {header}: {details['value']}")
    for item in data.get("missing_security_headers", []):
        print(f"  [MISSING] {item['header']} — {item['purpose']}")
    print("\nCORS probe:")
    for key, value in data.get("cors", {}).items():
        print(f"  {key}: {value}")
    print("\nNote: findings require manual validation. Missing headers are not automatically exploitable.")

def main():
    parser = argparse.ArgumentParser(description="Check HTTP security headers and basic CORS behavior.")
    parser.add_argument("url", help="Authorized target URL, e.g. https://example.com")
    parser.add_argument("--timeout", type=float, default=8.0, help="Request timeout in seconds (default: 8)")
    parser.add_argument("--json", dest="json_path", help="Save complete results to a JSON file")
    args = parser.parse_args()

    try:
        url = validate_url(args.url)
        data = scan(url, args.timeout)
        print_report(data)
        if args.json_path:
            with open(args.json_path, "w", encoding="utf-8") as file:
                json.dump(data, file, indent=2, ensure_ascii=False)
            print(f"\nJSON report saved to: {args.json_path}")
    except (ValueError, requests.RequestException) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
