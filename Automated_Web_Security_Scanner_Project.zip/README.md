# Automated Web Security Scanner

Educational Python project for checking selected HTTP security headers and observing basic CORS response fields.

## Safety
Use only on websites you own or have explicit permission to test. This is a lightweight checker, not a full audit.

## Setup
```bash
python -m pip install -r requirements.txt
```

## Run
```bash
python web_security_scanner.py https://your-authorized-test-site.example
python web_security_scanner.py https://your-authorized-test-site.example --json report.json
```

See `Automated_Web_Security_Scanner_Project_Report.docx` for the project report.
